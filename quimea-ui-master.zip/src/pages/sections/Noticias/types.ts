export interface INewsCardData {
  title: string;
  image_dir: string;
  date: string;
  slug: string;
}
