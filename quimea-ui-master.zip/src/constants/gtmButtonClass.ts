export const gtmButtonClass = 'gtm-link-event';
