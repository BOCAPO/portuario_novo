import MapsFrame from './MapsFrame';

export { MapsFrame as default };
