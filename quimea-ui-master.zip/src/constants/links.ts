export const links = {
  home: '/',
  pedidos: '/pedidos',
  account: '/conta',
  checkout: '/checkout',
};
