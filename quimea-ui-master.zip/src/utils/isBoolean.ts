export const isBoolean = (value: any): value is boolean =>
  typeof value === 'boolean';
