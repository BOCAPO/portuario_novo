module.exports = {
  plugins: {
    autoprefixer: {
      BrowsersList: ['>1%', 'ie 11', 'not ie < 11', 'not dead'],
    },
  },
};
