export interface IServiceUserPasswordResetData {
  new_password1: string;
  new_password2: string;
  token: string;
  uid: string;
}
