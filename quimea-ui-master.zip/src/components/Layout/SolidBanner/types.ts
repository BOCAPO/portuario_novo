export interface ISolidBannerProps {
  backgroundColor: 'green' | 'blue' | 'orange';
  title: string;
}
