export interface IProductsInCart {
  name: string;
  productId: number;
  unitaryValue: number;
  quantity: number;
  observation: string;
  unity: string;
}
