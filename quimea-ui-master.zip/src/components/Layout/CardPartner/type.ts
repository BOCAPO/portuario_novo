export interface ICardPartner {
  image: string;
  title: string;
  city: string;
}
