export const apiUrl = 'https://quimea-hml.growtechnologies.com.br';
export const partner = '/quimea';
