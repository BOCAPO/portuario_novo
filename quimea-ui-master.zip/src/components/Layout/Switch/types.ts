export interface ISwitchProps {
  firstOption: string;
  secondOption: string;

  onClick?: () => any;
  className?: string;
}
